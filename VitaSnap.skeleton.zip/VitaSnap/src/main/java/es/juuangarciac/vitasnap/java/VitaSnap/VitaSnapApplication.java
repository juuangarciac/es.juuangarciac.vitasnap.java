package es.juuangarciac.vitasnap.java.VitaSnap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VitaSnapApplication {

	public static void main(String[] args) {
		SpringApplication.run(VitaSnapApplication.class, args);
	}

}
