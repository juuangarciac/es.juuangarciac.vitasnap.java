package es.juuangarciac.vitasnap.java.VitaSnap;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VitaSnapApplicationTests {

	@Test
	void contextLoads() {
	}

}
